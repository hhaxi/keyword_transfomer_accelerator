# ref32_packed_pause

独立本科FFN1候选；数值格式和输出协议与同组对照相同。

- MAC：32；本地SRAM：35 KiB（不含共享SRAM/TCM）。
- 复位任务严格窗口平均：74716.5拍；连续任务平均：74866.8拍。
- 相对原最快版周期减少：0.00%。
- 150MHz折算：0.498110 ms，2007.59 task/s。
- task00 FIFO满等待：1539拍；DMA请求等待：274拍。
- 12次复位＋12次连续任务，输出逐位核对通过。

面积、时序、活动功耗与任务能量未在本机测量。
在交付根目录运行：`bash run_server.sh --quick --case ref32_packed_pause`。
本组配置见case.json；完整日志与证据见交付根目录reports。
