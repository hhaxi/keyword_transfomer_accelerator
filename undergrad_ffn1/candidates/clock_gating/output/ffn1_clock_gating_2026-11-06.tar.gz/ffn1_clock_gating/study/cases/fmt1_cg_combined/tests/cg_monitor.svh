// Generated scoreboard: strict task window, no DUT traffic changes.
bit cg_active=0; longint cg_root_edges=0; longint cg_last_root_fs=0;
longint cg_seen[0:11]; longint cg_expected[0:11];
task automatic cg_begin; begin cg_root_edges=0;
for(integer i=0;i<12;i++)begin cg_seen[i]=0;cg_expected[i]=0;end
cg_active=1; end endtask
always @(posedge clk)begin
cg_last_root_fs=measurement_clock.now_fs();
if(cg_active)begin cg_root_edges++;
if(dut.bus.accelerator.tile_engine.core.result_queue.banks[0].clock_groups[0].u_gate.en || dut.bus.accelerator.tile_engine.core.result_queue.banks[0].clock_groups[0].u_gate.test_en) cg_expected[0]++;
if(dut.bus.accelerator.tile_engine.core.result_queue.banks[0].clock_groups[1].u_gate.en || dut.bus.accelerator.tile_engine.core.result_queue.banks[0].clock_groups[1].u_gate.test_en) cg_expected[1]++;
if(dut.bus.accelerator.tile_engine.core.result_queue.banks[0].clock_groups[2].u_gate.en || dut.bus.accelerator.tile_engine.core.result_queue.banks[0].clock_groups[2].u_gate.test_en) cg_expected[2]++;
if(dut.bus.accelerator.tile_engine.core.result_queue.banks[0].clock_groups[3].u_gate.en || dut.bus.accelerator.tile_engine.core.result_queue.banks[0].clock_groups[3].u_gate.test_en) cg_expected[3]++;
if(dut.bus.accelerator.tile_engine.core.mac_clock_groups[0].u_gate.en || dut.bus.accelerator.tile_engine.core.mac_clock_groups[0].u_gate.test_en) cg_expected[4]++;
if(dut.bus.accelerator.tile_engine.core.mac_clock_groups[1].u_gate.en || dut.bus.accelerator.tile_engine.core.mac_clock_groups[1].u_gate.test_en) cg_expected[5]++;
if(dut.bus.accelerator.tile_engine.core.mac_clock_groups[2].u_gate.en || dut.bus.accelerator.tile_engine.core.mac_clock_groups[2].u_gate.test_en) cg_expected[6]++;
if(dut.bus.accelerator.tile_engine.core.mac_clock_groups[3].u_gate.en || dut.bus.accelerator.tile_engine.core.mac_clock_groups[3].u_gate.test_en) cg_expected[7]++;
if(dut.bus.accelerator.formatter.partial_groups[0].u_gate.en || dut.bus.accelerator.formatter.partial_groups[0].u_gate.test_en) cg_expected[8]++;
if(dut.bus.accelerator.formatter.partial_groups[1].u_gate.en || dut.bus.accelerator.formatter.partial_groups[1].u_gate.test_en) cg_expected[9]++;
if(dut.bus.accelerator.formatter.partial_groups[2].u_gate.en || dut.bus.accelerator.formatter.partial_groups[2].u_gate.test_en) cg_expected[10]++;
if(dut.bus.accelerator.formatter.completed_groups[0].u_gate.en || dut.bus.accelerator.formatter.completed_groups[0].u_gate.test_en) cg_expected[11]++;
#0.000001;
if(cg_seen[0]!=cg_expected[0])$fatal(1,"Missing/extra gated edge: result_r0");
if(cg_seen[1]!=cg_expected[1])$fatal(1,"Missing/extra gated edge: result_r1");
if(cg_seen[2]!=cg_expected[2])$fatal(1,"Missing/extra gated edge: result_r2");
if(cg_seen[3]!=cg_expected[3])$fatal(1,"Missing/extra gated edge: result_r3");
if(cg_seen[4]!=cg_expected[4])$fatal(1,"Missing/extra gated edge: mac_r0");
if(cg_seen[5]!=cg_expected[5])$fatal(1,"Missing/extra gated edge: mac_r1");
if(cg_seen[6]!=cg_expected[6])$fatal(1,"Missing/extra gated edge: mac_r2");
if(cg_seen[7]!=cg_expected[7])$fatal(1,"Missing/extra gated edge: mac_r3");
if(cg_seen[8]!=cg_expected[8])$fatal(1,"Missing/extra gated edge: partial0");
if(cg_seen[9]!=cg_expected[9])$fatal(1,"Missing/extra gated edge: partial1");
if(cg_seen[10]!=cg_expected[10])$fatal(1,"Missing/extra gated edge: partial2");
if(cg_seen[11]!=cg_expected[11])$fatal(1,"Missing/extra gated edge: completed");
end end
always @(posedge dut.bus.accelerator.tile_engine.core.result_queue.banks[0].clock_groups[0].u_gate.gclk)begin
if(clk!==1'b1 || measurement_clock.now_fs()!=cg_last_root_fs)$fatal(1,"Off-edge gate pulse: result_r0");
if(cg_active)cg_seen[0]++;end
always @(posedge dut.bus.accelerator.tile_engine.core.result_queue.banks[0].clock_groups[1].u_gate.gclk)begin
if(clk!==1'b1 || measurement_clock.now_fs()!=cg_last_root_fs)$fatal(1,"Off-edge gate pulse: result_r1");
if(cg_active)cg_seen[1]++;end
always @(posedge dut.bus.accelerator.tile_engine.core.result_queue.banks[0].clock_groups[2].u_gate.gclk)begin
if(clk!==1'b1 || measurement_clock.now_fs()!=cg_last_root_fs)$fatal(1,"Off-edge gate pulse: result_r2");
if(cg_active)cg_seen[2]++;end
always @(posedge dut.bus.accelerator.tile_engine.core.result_queue.banks[0].clock_groups[3].u_gate.gclk)begin
if(clk!==1'b1 || measurement_clock.now_fs()!=cg_last_root_fs)$fatal(1,"Off-edge gate pulse: result_r3");
if(cg_active)cg_seen[3]++;end
always @(posedge dut.bus.accelerator.tile_engine.core.mac_clock_groups[0].u_gate.gclk)begin
if(clk!==1'b1 || measurement_clock.now_fs()!=cg_last_root_fs)$fatal(1,"Off-edge gate pulse: mac_r0");
if(cg_active)cg_seen[4]++;end
always @(posedge dut.bus.accelerator.tile_engine.core.mac_clock_groups[1].u_gate.gclk)begin
if(clk!==1'b1 || measurement_clock.now_fs()!=cg_last_root_fs)$fatal(1,"Off-edge gate pulse: mac_r1");
if(cg_active)cg_seen[5]++;end
always @(posedge dut.bus.accelerator.tile_engine.core.mac_clock_groups[2].u_gate.gclk)begin
if(clk!==1'b1 || measurement_clock.now_fs()!=cg_last_root_fs)$fatal(1,"Off-edge gate pulse: mac_r2");
if(cg_active)cg_seen[6]++;end
always @(posedge dut.bus.accelerator.tile_engine.core.mac_clock_groups[3].u_gate.gclk)begin
if(clk!==1'b1 || measurement_clock.now_fs()!=cg_last_root_fs)$fatal(1,"Off-edge gate pulse: mac_r3");
if(cg_active)cg_seen[7]++;end
always @(posedge dut.bus.accelerator.formatter.partial_groups[0].u_gate.gclk)begin
if(clk!==1'b1 || measurement_clock.now_fs()!=cg_last_root_fs)$fatal(1,"Off-edge gate pulse: partial0");
if(cg_active)cg_seen[8]++;end
always @(posedge dut.bus.accelerator.formatter.partial_groups[1].u_gate.gclk)begin
if(clk!==1'b1 || measurement_clock.now_fs()!=cg_last_root_fs)$fatal(1,"Off-edge gate pulse: partial1");
if(cg_active)cg_seen[9]++;end
always @(posedge dut.bus.accelerator.formatter.partial_groups[2].u_gate.gclk)begin
if(clk!==1'b1 || measurement_clock.now_fs()!=cg_last_root_fs)$fatal(1,"Off-edge gate pulse: partial2");
if(cg_active)cg_seen[10]++;end
always @(posedge dut.bus.accelerator.formatter.completed_groups[0].u_gate.gclk)begin
if(clk!==1'b1 || measurement_clock.now_fs()!=cg_last_root_fs)$fatal(1,"Off-edge gate pulse: completed");
if(cg_active)cg_seen[11]++;end
task automatic cg_end;begin #0.000001; cg_active=0;
$display("CG_WINDOW task=%0d root_edges=%0d gates=12",taskid,cg_root_edges);
$display("CG_ACTIVITY task=%0d gate=result_r0 edges=%0d expected=%0d root_edges=%0d bits=320",taskid,cg_seen[0],cg_expected[0],cg_root_edges);
$display("CG_ACTIVITY task=%0d gate=result_r1 edges=%0d expected=%0d root_edges=%0d bits=320",taskid,cg_seen[1],cg_expected[1],cg_root_edges);
$display("CG_ACTIVITY task=%0d gate=result_r2 edges=%0d expected=%0d root_edges=%0d bits=320",taskid,cg_seen[2],cg_expected[2],cg_root_edges);
$display("CG_ACTIVITY task=%0d gate=result_r3 edges=%0d expected=%0d root_edges=%0d bits=320",taskid,cg_seen[3],cg_expected[3],cg_root_edges);
$display("CG_ACTIVITY task=%0d gate=mac_r0 edges=%0d expected=%0d root_edges=%0d bits=320",taskid,cg_seen[4],cg_expected[4],cg_root_edges);
$display("CG_ACTIVITY task=%0d gate=mac_r1 edges=%0d expected=%0d root_edges=%0d bits=320",taskid,cg_seen[5],cg_expected[5],cg_root_edges);
$display("CG_ACTIVITY task=%0d gate=mac_r2 edges=%0d expected=%0d root_edges=%0d bits=320",taskid,cg_seen[6],cg_expected[6],cg_root_edges);
$display("CG_ACTIVITY task=%0d gate=mac_r3 edges=%0d expected=%0d root_edges=%0d bits=320",taskid,cg_seen[7],cg_expected[7],cg_root_edges);
$display("CG_ACTIVITY task=%0d gate=partial0 edges=%0d expected=%0d root_edges=%0d bits=55",taskid,cg_seen[8],cg_expected[8],cg_root_edges);
$display("CG_ACTIVITY task=%0d gate=partial1 edges=%0d expected=%0d root_edges=%0d bits=40",taskid,cg_seen[9],cg_expected[9],cg_root_edges);
$display("CG_ACTIVITY task=%0d gate=partial2 edges=%0d expected=%0d root_edges=%0d bits=40",taskid,cg_seen[10],cg_expected[10],cg_root_edges);
$display("CG_ACTIVITY task=%0d gate=completed edges=%0d expected=%0d root_edges=%0d bits=176",taskid,cg_seen[11],cg_expected[11],cg_root_edges);
end endtask
