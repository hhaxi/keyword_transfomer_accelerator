// Lossless formatter: independent assembly and a parameterized completed-group FIFO.
// Each queue entry owns its address. A stalled word and address remain stable.
module kwt_output_formatter #(parameter PACKED40=0, parameter DEPTH=1) (
 input wire clk, rst_n, clear,
 input wire in_valid, output wire in_ready,
 input wire [39:0] in_data, input wire [14:0] in_index,
 output wire out_valid, input wire out_ready,
 output wire [31:0] out_data, output wire [15:0] out_index,
 output wire empty, output wire fault
);
 reg [119:0] partial;
 reg [1:0] gathered;
 reg [14:0] first_index;
 reg [159:0] payload [0:DEPTH-1];
 reg [15:0] address [0:DEPTH-1];
 reg head, tail;
 localparam COUNT_BITS = DEPTH == 1 ? 1 : 2;
 reg [COUNT_BITS-1:0] count;
 integer entry;
 generate if(DEPTH!=1 && DEPTH!=2) begin:invalid_depth
 KWT_FORMATTER_DEPTH_REQUIRED invalid_configuration();
 end endgenerate
 reg [2:0] word_pos;
 reg fault_reg;
 localparam LAST_WORD = PACKED40 ? 4 : 1;
 wire enabled = rst_n && !clear && !fault_reg;
 wire retire = out_valid && out_ready && word_pos == LAST_WORD;
 wire space = count < DEPTH || retire;
 wire take = in_valid && in_ready;
 wire index_ok = !PACKED40 ||
                 (gathered == 0 ? in_index[1:0] == 0 :
                  {1'b0,in_index} == {1'b0,first_index}+gathered);
 wire publish = take && index_ok && (!PACKED40 || gathered == 3);
 assign in_ready = enabled && (PACKED40 && gathered != 3 || space);
 assign out_valid = enabled && count != 0;
 assign out_data = payload[head][word_pos*32 +: 32];
 assign out_index = address[head] + word_pos;
 assign empty = count == 0 && gathered == 0;
 assign fault = fault_reg;

 // Only data storage is gated; queue/control handshakes keep root clk.
 wire [2:0] partial_clk;
 genvar slice,bank;
 generate for(slice=0;slice<3;slice=slice+1)begin:partial_groups
   kwt_clock_gate u_gate(.clk(clk),.test_en(1'b0),
     .en(clear || (take && index_ok && PACKED40 && gathered==slice)),
     .gclk(partial_clk[slice]));
   always @(posedge partial_clk[slice] or negedge rst_n)begin
     if(!rst_n)partial[slice*40+:40]<=0;
     else if(clear)partial[slice*40+:40]<=0;
     else if(take && index_ok && PACKED40 && gathered==slice)
       partial[slice*40+:40]<=in_data;
   end
 end
 for(bank=0;bank<DEPTH;bank=bank+1)begin:completed_groups
   wire payload_clk;
   kwt_clock_gate u_gate(.clk(clk),.test_en(1'b0),
     .en(clear || (publish && tail==bank)),.gclk(payload_clk));
   always @(posedge payload_clk or negedge rst_n)begin
     if(!rst_n)begin payload[bank]<=0;address[bank]<=0;end
     else if(clear)begin payload[bank]<=0;address[bank]<=0;end
     else if(publish && tail==bank)begin
       if(!PACKED40)begin
         payload[bank]<={96'b0,{24{in_data[39]}},in_data};
         address[bank]<={in_index,1'b0};
       end else begin
         payload[bank]<={in_data,partial};
         address[bank]<=({3'b0,first_index[14:2]}<<2)+{3'b0,first_index[14:2]};
       end
     end
   end
 end endgenerate
 always @(posedge partial_clk[0] or negedge rst_n)begin
   if(!rst_n)first_index<=0;
   else if(clear)first_index<=0;
   else if(take && index_ok && PACKED40 && gathered==0)first_index<=in_index;
 end

 always @(posedge clk or negedge rst_n) begin
   if (!rst_n) begin
     gathered<=0; head<=0; tail<=0;
     count<=0; word_pos<=0; fault_reg<=0;
   end else if (clear) begin
     gathered<=0; head<=0; tail<=0;
     count<=0; word_pos<=0; fault_reg<=0;
   end else begin
     if (out_valid && out_ready) begin
       if (retire) begin head<=(DEPTH==1 ? 1'b0 : !head); word_pos<=0; end
       else word_pos<=word_pos+1'b1;
     end
     case ({publish,retire})
       2'b10: count<=count+1'b1;
       2'b01: count<=count-1'b1;
       default: begin end
     endcase
     if (take) begin
       if (!index_ok) fault_reg<=1;
       else if (!PACKED40) begin
         tail<=(DEPTH==1 ? 1'b0 : !tail);
       end else if (gathered==3) begin
         tail<=(DEPTH==1 ? 1'b0 : !tail); gathered<=0;
       end else begin
         gathered<=gathered+1'b1;
       end
     end
   end
 end
endmodule
