// Generated scoreboard: strict task window, no DUT traffic changes.
bit cg_active=0; longint cg_root_edges=0; longint cg_last_root_fs=0;
longint cg_seen[0:3]; longint cg_expected[0:3];
task automatic cg_begin; begin cg_root_edges=0;
for(integer i=0;i<4;i++)begin cg_seen[i]=0;cg_expected[i]=0;end
cg_active=1; end endtask
always @(posedge clk)begin
cg_last_root_fs=measurement_clock.now_fs();
if(cg_active)begin cg_root_edges++;
if(dut.bus.accelerator.formatter.partial_groups[0].u_gate.en || dut.bus.accelerator.formatter.partial_groups[0].u_gate.test_en) cg_expected[0]++;
if(dut.bus.accelerator.formatter.partial_groups[1].u_gate.en || dut.bus.accelerator.formatter.partial_groups[1].u_gate.test_en) cg_expected[1]++;
if(dut.bus.accelerator.formatter.partial_groups[2].u_gate.en || dut.bus.accelerator.formatter.partial_groups[2].u_gate.test_en) cg_expected[2]++;
if(dut.bus.accelerator.formatter.completed_groups[0].u_gate.en || dut.bus.accelerator.formatter.completed_groups[0].u_gate.test_en) cg_expected[3]++;
#0.000001;
if(cg_seen[0]!=cg_expected[0])$fatal(1,"Missing/extra gated edge: partial0");
if(cg_seen[1]!=cg_expected[1])$fatal(1,"Missing/extra gated edge: partial1");
if(cg_seen[2]!=cg_expected[2])$fatal(1,"Missing/extra gated edge: partial2");
if(cg_seen[3]!=cg_expected[3])$fatal(1,"Missing/extra gated edge: completed");
end end
always @(posedge dut.bus.accelerator.formatter.partial_groups[0].u_gate.gclk)begin
if(clk!==1'b1 || measurement_clock.now_fs()!=cg_last_root_fs)$fatal(1,"Off-edge gate pulse: partial0");
if(cg_active)cg_seen[0]++;end
always @(posedge dut.bus.accelerator.formatter.partial_groups[1].u_gate.gclk)begin
if(clk!==1'b1 || measurement_clock.now_fs()!=cg_last_root_fs)$fatal(1,"Off-edge gate pulse: partial1");
if(cg_active)cg_seen[1]++;end
always @(posedge dut.bus.accelerator.formatter.partial_groups[2].u_gate.gclk)begin
if(clk!==1'b1 || measurement_clock.now_fs()!=cg_last_root_fs)$fatal(1,"Off-edge gate pulse: partial2");
if(cg_active)cg_seen[2]++;end
always @(posedge dut.bus.accelerator.formatter.completed_groups[0].u_gate.gclk)begin
if(clk!==1'b1 || measurement_clock.now_fs()!=cg_last_root_fs)$fatal(1,"Off-edge gate pulse: completed");
if(cg_active)cg_seen[3]++;end
task automatic cg_end;begin #0.000001; cg_active=0;
$display("CG_WINDOW task=%0d root_edges=%0d gates=4",taskid,cg_root_edges);
$display("CG_ACTIVITY task=%0d gate=partial0 edges=%0d expected=%0d root_edges=%0d bits=55",taskid,cg_seen[0],cg_expected[0],cg_root_edges);
$display("CG_ACTIVITY task=%0d gate=partial1 edges=%0d expected=%0d root_edges=%0d bits=40",taskid,cg_seen[1],cg_expected[1],cg_root_edges);
$display("CG_ACTIVITY task=%0d gate=partial2 edges=%0d expected=%0d root_edges=%0d bits=40",taskid,cg_seen[2],cg_expected[2],cg_root_edges);
$display("CG_ACTIVITY task=%0d gate=completed edges=%0d expected=%0d root_edges=%0d bits=176",taskid,cg_seen[3],cg_expected[3],cg_root_edges);
end endtask
