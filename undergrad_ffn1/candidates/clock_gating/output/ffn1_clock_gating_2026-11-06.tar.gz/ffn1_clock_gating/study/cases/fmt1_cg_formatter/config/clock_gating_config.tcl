set kwt_cg_expected 4
