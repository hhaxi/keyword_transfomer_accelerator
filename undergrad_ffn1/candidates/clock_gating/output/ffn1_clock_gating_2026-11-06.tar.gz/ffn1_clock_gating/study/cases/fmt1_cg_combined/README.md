# fmt1_cg_combined

复位平均 55416.5 拍，连续平均 55558.583 拍；全部逐任务时长和计数与 fmt1_ref 一致。

计划 ICG 12 个，受控数据寄存器 2871 位；实际库映射/时序/功耗待服务器验证。
前端受控寄存器时钟沿×位数减少 77.52%，不是功耗降幅。

在交付根目录运行 `bash run_server.sh --quick --case fmt1_cg_combined`，入口自动带上 fmt1_ref。
