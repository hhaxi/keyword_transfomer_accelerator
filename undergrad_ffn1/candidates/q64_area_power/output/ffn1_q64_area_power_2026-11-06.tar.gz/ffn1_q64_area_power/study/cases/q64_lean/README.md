# q64_lean

父项：q64_bank1_mac38；设计变更见交付根目录 README、PLAN 和本目录 case.json。

12 次复位＋12 次连续任务逐位正确。复位平均 55416.5 拍，连续平均 55558.583 拍；相对 q64_ref 增加 +52.0 拍（+0.0939%）。

64 MAC、37 KiB 本地 SRAM；通用寄存器 4020 位，mux 输出位 9598。这些是 RTL 结构指标，实际面积、活动功耗和时序待服务器验证。

从交付根目录运行 `bash run_server.sh --quick --case q64_lean`。
